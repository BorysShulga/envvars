# AEM Environment Variables Servlet

This project provides an Adobe Experience Manager (AEM) servlet that displays system environment variables in a beautiful, responsive web interface.

## Features

- 🌐 **Web Interface**: Beautiful, responsive HTML page showing all environment variables
- 🔍 **Search Functionality**: Real-time search through environment variables
- 📊 **System Statistics**: Display of Java version, OS information, and variable count
- 🎨 **Modern UI**: Clean, professional design with gradient headers and interactive elements
- 🔒 **Security**: HTML escaping to prevent XSS attacks

## Project Structure

```
├── pom.xml                                          # Maven configuration
├── src/main/java/com/example/aem/servlet/
│   └── EnvironmentVariablesServlet.java            # Main servlet implementation
├── src/main/content/
│   ├── META-INF/vault/                             # Vault package metadata
│   │   ├── config.xml
│   │   ├── filter.xml
│   │   └── properties.xml
│   └── jcr_root/apps/example-aem/
│       └── .content.xml                            # JCR content definition
└── README.md
```

## Prerequisites

- Java 11 or higher
- Maven 3.6 or higher
- Adobe Experience Manager 6.5+ or AEM as a Cloud Service

## Build Instructions

### 1. Compile and Package

```bash
mvn clean package
```

This command will:
- Compile the Java servlet code
- Create an OSGi bundle
- Package everything into a deployable AEM content package (ZIP file)

### 2. Build Location

The deployable package will be created at:
```
target/environment-variables-servlet-1.0.0-SNAPSHOT.zip
```

## Installation in AEM

### Option 1: Manual Installation via Package Manager

1. Open AEM Package Manager: `http://localhost:4502/crx/packmgr/index.jsp`
2. Click "Upload Package"
3. Select the generated ZIP file from `target/` directory
4. Click "Install" on the uploaded package

### Option 2: Automated Installation via Maven

```bash
mvn clean package -PautoInstallPackage
```

This will automatically build and install the package to your local AEM instance.

### Option 3: Custom AEM Instance

If your AEM instance is not running on localhost:4502, you can specify custom connection details:

```bash
mvn clean package -PautoInstallPackage -Daem.host=your-aem-host -Daem.port=4502 -Daem.username=admin -Daem.password=admin
```

## Usage

Once installed, access the servlet at:

```
http://localhost:4502/bin/environment-variables
```

The page will display:
- Total count of environment variables
- Java version and operating system information
- Searchable table of all environment variables
- Real-time filtering capability

## Development

### Modifying the Servlet

The main servlet code is located at:
```
src/main/java/com/example/aem/servlet/EnvironmentVariablesServlet.java
```

Key features of the servlet:
- **Path**: `/bin/environment-variables`
- **Method**: GET only
- **Output**: HTML with embedded CSS and JavaScript
- **Security**: HTML escaping for all output

### Adding New Features

To extend the servlet functionality:

1. Modify `EnvironmentVariablesServlet.java`
2. Rebuild with `mvn clean package`
3. Reinstall the package in AEM

### Styling and UI

The servlet generates a complete HTML page with embedded CSS. To modify the appearance:
- Edit the CSS styles in the `doGet()` method
- The design uses modern CSS3 features including gradients and flexbox
- Colors and styling follow Adobe's design principles

## Configuration

### Maven Properties

You can customize the build by modifying these properties in `pom.xml`:

- `aem.host`: AEM server hostname (default: localhost)
- `aem.port`: AEM server port (default: 4502)
- `aem.username`: AEM admin username (default: admin)
- `aem.password`: AEM admin password (default: admin)

### OSGi Configuration

The servlet is automatically registered as an OSGi service with these properties:
- Service path: `/bin/environment-variables`
- HTTP method: GET
- Component: `com.example.aem.servlet.EnvironmentVariablesServlet`

## Security Considerations

- The servlet only accepts GET requests
- All output is HTML-escaped to prevent XSS attacks
- The servlet path is publicly accessible (consider adding authentication if needed)
- Environment variables may contain sensitive information

## Troubleshooting

### Common Issues

1. **Package installation fails**
   - Check AEM logs: `error.log` and `request.log`
   - Verify AEM is running and accessible
   - Ensure correct credentials

2. **Servlet not accessible**
   - Check if the bundle is active in OSGi console: `/system/console/bundles`
   - Verify servlet registration in OSGi console: `/system/console/services`

3. **Build failures**
   - Ensure Java 11+ and Maven 3.6+ are installed
   - Check internet connectivity for dependency downloads

### Logs

Check AEM logs for servlet activity:
```bash
tail -f crx-quickstart/logs/error.log
tail -f crx-quickstart/logs/request.log
```

## License

This project is provided as-is for educational and demonstration purposes.

## Support

For issues and questions:
1. Check the AEM documentation
2. Review OSGi console for bundle status
3. Examine AEM log files for errors